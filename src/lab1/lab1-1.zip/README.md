# CSC365-Lab1
Lab 1 for CSC 365

To run the program: run schoolsearch.py or the Makefile in command prompt under the src directory
